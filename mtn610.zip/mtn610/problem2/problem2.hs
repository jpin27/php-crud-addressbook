-- Mark Nguyen
-- mtn610
-- 11143312

--Composition takes in three arguments, 
--two of which are functions and the 
--third is of type Double.
composition :: (Double -> Double) -> (Double -> Double) -> Double -> Double
composition f g x = f(g x)
