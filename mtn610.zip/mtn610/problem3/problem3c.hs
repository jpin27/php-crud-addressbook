-- Mark Nguyen
-- mtn610
-- 11143312

--Return the last element of a given list.
--If the list is empty, then an empty list is returned.
safetail :: [a] -> [a]
safetail []=[]
safetail (x:xs) = safetail2 (x:xs)
	where
		safetail2 (x:[]) = [x]
		safetail2 (_:xs) = safetail xs