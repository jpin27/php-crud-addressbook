-- Mark Nguyen
-- mtn610
-- 11143312

--Return the last element of a given list.
--If the list is empty, then an empty list is returned.
safetail :: [a] -> [a]
safetail ([]) = []
safetail (x:xs) =
	if(length xs == 0) then
		[x]
	else
		safetail xs